package com.company;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Employees {

    String fn, ln, d, s;

    public Employees(String fname, String lname, String dep, String salary) {

        fn=fname; ln=lname; d=dep; s=salary;

    }


}
