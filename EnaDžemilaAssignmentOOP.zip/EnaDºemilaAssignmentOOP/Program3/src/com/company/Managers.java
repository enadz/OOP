package com.company;

public class Managers {


    String d, n, b;

    public Managers(String dep, String name, String budget) {

        n=name; d=dep; b=budget;

    }



}
