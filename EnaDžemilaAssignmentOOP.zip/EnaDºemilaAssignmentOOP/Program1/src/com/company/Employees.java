package com.company;

public class Employees {
    String fname, lname, name;
    Employees(String fn, String ln){
        fname=fn; lname=ln;
         name= fname+" "+ lname;
    }


}
